// Adiciona um evento que aguarda o carregamento completo do conteúdo do DOM
document.addEventListener('DOMContentLoaded', function() {
    // Alerta de boas-vindas
    alert('Bem-vindo ao Retro Games! Explore nossos produtos e divirta-se.');

    // Produtos carregados diretamente no código em um array de objetos
    const products = [
        {
            "id": 1,
            "name": "GTA San Andreas",
            "category": ["action", "open world"],
            "price": "R$ 39,99",
            "image": "retrogames/css/img/p1.jpg"
        },
        {
            "id": 2,
            "name": "Halo 3",
            "category": ["fps", "action", "adventure"],
            "price": "R$ 27,58",
            "image": "retrogames/css/img/p2.jpg"
        },
        {
            "id": 3,
            "name": "Final Fantasy X",
            "category": ["rpg"],
            "price": "R$ 48,79",
            "image": "retrogames/css/img/p3.jpg"
        },
        {
            "id": 4,
            "name": "Resident Evil 4",
            "category": ["horror", "action"],
            "price": "R$ 37,84",
            "image": "retrogames/css/img/p4.jpg"
        },
        {
            "id": 5,
            "name": "Half life 3",
            "category": ["puzzle"],
            "price": "R$ 45,80",
            "image": "retrogames/css/img/p5.jpg"
        },
        {
            "id": 6,
            "name": "Super Smash Bros",
            "category": ["action"],
            "price": "R$ 74,80",
            "image": "retrogames/css/img/p6.jpg"
        },
        {
            "id": 7,
            "name": "Silent Hill 2",
            "category": ["horror"],
            "price": "R$ 69,85",
            "image": "retrogames/css/img/p7.jpg"
        },
        {
            "id": 8,
            "name": "Devil May Cry 3",
            "category": ["horror", "action"],
            "price": "R$ 48,90",
            "image": "retrogames/css/img/p8.jpg"
        },
        {
            "id": 9,
            "name": "Pokemon Red",
            "category": ["adventure", "open world"],
            "price": "R$ 17,80",
            "image": "retrogames/css/img/p9.jpg"
        },
        {
            "id": 10,
            "name": "Tony Hawks Pro Skater 2",
            "category": ["sports", "action"],
            "price": "R$ 16,40",
            "image": "retrogames/css/img/p10.jpg"
        },
        {
            "id": 11,
            "name": "Metal Gear Solid 3",
            "category": ["adventure", "action"],
            "price": "R$ 57,80",
            "image": "retrogames/css/img/p11.jpg"
        },
        {
            "id": 12,
            "name": "Tekken 5",
            "category": ["action"],
            "price": "R$ 26,04",
            "image": "retrogames/css/img/p12.jpg"
        },
        {
            "id": 13,
            "name": "Prince of Persia",
            "category": ["adventure", "action"],
            "price": "R$ 9,69",
            "image": "retrogames/css/img/p13.jpg"
        },
        {
            "id": 14,
            "name": "Metal Gear Solid 2",
            "category": ["adventure", "action"],
            "price": "R$ 29,42",
            "image": "retrogames/css/img/p14.jpg"
        },
        {
            "id": 15,
            "name": "Doom 3",
            "category": ["action"],
            "price": "R$ 59,99",
            "image": "retrogames/css/img/p15.jpg"
        },
        {
            "id": 16,
            "name": "Paper Mario",
            "category": ["adventure"],
            "price": "R$ 42,87",
            "image": "retrogames/css/img/p16.jpg"
        }
    ];
    
    // Seleção de elementos do DOM
    const productList = document.querySelector('.product-list');  // Obtém o contêiner onde os produtos serão exibidos
    const categoryFilter = document.getElementById('category-filter');  // Obtém o filtro de categorias
    const searchInput = document.getElementById('search-input');  // Obtém o campo de pesquisa

    // Função para exibir produtos na lista
    function displayProducts(productsToDisplay) {
        productList.innerHTML = ''; // Limpa a lista de produtos antes de exibir
        // Itera sobre cada produto a ser exibido
        productsToDisplay.forEach(product => {
            // Cria um novo elemento div para cada item do produto
            const productItem = document.createElement('div');
            productItem.className = 'product-item';  // Define a classe do item
            // Define o conteúdo HTML do item com imagem, nome, preço e botão de adicionar ao carrinho
            productItem.innerHTML = `
                <img src="${product.image}" alt="${product.name}">
                <div class="info">
                    <h3>${product.name}</h3>
                    <p class="price">${product.price}</p>
                    <button class="add-to-cart" data-id="${product.id}">Adicionar ao Carrinho</button>
                </div>
            `;
            // Adiciona o item à lista de produtos
            productList.appendChild(productItem);
        });
    }

    // Função para filtrar produtos com base em categorias e pesquisa
    function filterProducts(categories, search) {
        let filteredProducts = products;  // Inicializa a lista filtrada como a lista original de produtos

        // Filtrar produtos por categorias, se houver seleção
        if (categories.length > 0 && !categories.includes('all')) {
            filteredProducts = filteredProducts.filter(product =>
                product.category.some(cat => categories.includes(cat))  // Verifica se o produto pertence a uma das categorias selecionadas
            );
        }

        // Filtrar produtos com base na pesquisa do nome
        if (search) {
            filteredProducts = filteredProducts.filter(product =>
                product.name.toLowerCase().includes(search.toLowerCase())  // Verifica se o nome do produto inclui a string de pesquisa
            );
        }

        // Exibir os produtos filtrados
        displayProducts(filteredProducts);
    }

    // Exibir todos os produtos ao inicializar a página
    displayProducts(products);

    // Evento de mudança nas categorias do filtro
    categoryFilter.addEventListener('change', function() {
        // Obtém as categorias selecionadas e filtra os produtos
        const selectedCategories = Array.from(this.selectedOptions).map(option => option.value);
        filterProducts(selectedCategories, searchInput.value);
    });

    // Evento de entrada no campo de pesquisa
    searchInput.addEventListener('input', function() {
        // Obtém as categorias selecionadas e filtra os produtos com base na pesquisa
        const selectedCategories = Array.from(categoryFilter.selectedOptions).map(option => option.value);
        filterProducts(selectedCategories, this.value);
    });

    // Função para adicionar produto ao carrinho e armazenar no localStorage
    function handleAddToCart(event) {
        // Verifica se o alvo do evento é um botão de adicionar ao carrinho
        if (event.target.classList.contains('add-to-cart')) {
            const productId = event.target.getAttribute('data-id');  // Obtém o ID do produto do atributo data-id
            const product = products.find(p => p.id == productId);  // Encontra o produto correspondente ao ID
    
            // Recupera o carrinho atual ou cria um novo se não existir
            let cart = JSON.parse(localStorage.getItem('cart')) || [];
    
            // Adiciona o produto ao carrinho
            cart.push(product);
    
            // Armazena o carrinho atualizado no localStorage
            localStorage.setItem('cart', JSON.stringify(cart));
    
            // Alerta ao usuário que o produto foi adicionado ao carrinho
            alert(`Produto "${product.name}" adicionado ao carrinho.`);
        }
    }

    // Evento para adicionar produto ao carrinho ao clicar no botão
    productList.addEventListener('click', handleAddToCart);

    // Funções de gerenciamento de cookies para salvar as categorias selecionadas
    function setCookie(name, value, days) {
        let expires = "";
        if (days) {
            const date = new Date();  // Cria um novo objeto de data
            date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));  // Calcula a data de expiração
            expires = "; expires=" + date.toUTCString();  // Define o formato da expiração do cookie
        }
        // Define o cookie com o nome, valor e expiração
        document.cookie = name + "=" + (value || "") + expires + "; path=/";
    }

    function getCookie(name) {
        const nameEQ = name + "=";  // Define a string para busca do cookie
        const ca = document.cookie.split(';');  // Separa todos os cookies em um array
        for (let i = 0; i < ca.length; i++) {
            let c = ca[i];
            // Remove espaços em branco do início da string
            while (c.charAt(0) === ' ') c = c.substring(1, c.length);
            // Verifica se o cookie corresponde ao nome procurado
            if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length);  // Retorna o valor do cookie
        }
        return null;  // Retorna null se o cookie não for encontrado
    }

    // Função para iniciar o temporizador de inatividade
    function startIdleTimer() {
        let timeout;  // Variável para armazenar o ID do temporizador
        function resetTimer() {
            clearTimeout(timeout);  // Limpa o temporizador anterior
            // Inicia um novo temporizador que alerta após 5 minutos de inatividade
            timeout = setTimeout(() => alert('Você ficou inativo por 5 minutos!'), 5 * 60 * 1000);
        }

        // Adiciona eventos de movimento do mouse e pressionamento de tecla para reiniciar o temporizador
        document.addEventListener('mousemove', resetTimer);
        document.addEventListener('keypress', resetTimer);
        resetTimer();  // Chama a função inicialmente para iniciar o temporizador
    }

    // Inicializar filtros com base nos cookies salvos
    const savedCategories = getCookie('selectedCategories');  // Obtém categorias salvas nos cookies
    if (savedCategories) {
        const categoriesArray = savedCategories.split(',');  // Converte a string de categorias em um array
        Array.from(categoryFilter.options).forEach(option => {
            // Marca as opções do filtro que estão salvas nos cookies como selecionadas
            option.selected = categoriesArray.includes(option.value);
        });
        // Filtra e exibe os produtos com base nas categorias salvas
        filterProducts(categoriesArray, searchInput.value);
    } else {
        // Se não houver categorias salvas, exibe todos os produtos
        displayProducts(products);
    }

    // Salva a seleção de categorias em cookies quando houver alteração
    categoryFilter.addEventListener('change', function() {
        const selectedCategories = Array.from(this.selectedOptions).map(option => option.value);
        // Salva as categorias selecionadas nos cookies por 7 dias
        setCookie('selectedCategories', selectedCategories.join(','), 7);
        filterProducts(selectedCategories, searchInput.value);  // Filtra e exibe os produtos
    });

    // Iniciar o temporizador de inatividade
    startIdleTimer();
});
