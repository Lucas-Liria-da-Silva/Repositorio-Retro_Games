// Adiciona um evento que aguarda o carregamento completo do conteúdo do DOM
document.addEventListener('DOMContentLoaded', function () {
    // Obtém o elemento onde os itens do carrinho serão exibidos
    const cartItemsContainer = document.getElementById('cart-items');
    // Obtém o botão para limpar o carrinho
    const clearCartButton = document.getElementById('clear-cart');

    // Recupera o carrinho do localStorage ou inicializa como um array vazio
    let cart = JSON.parse(localStorage.getItem('cart')) || [];

    // Função para exibir os itens do carrinho
    function displayCartItems() {
        // Limpa o conteúdo atual do contêiner de itens do carrinho
        cartItemsContainer.innerHTML = '';
        // Verifica se o carrinho está vazio
        if (cart.length === 0) {
            // Se vazio, exibe uma mensagem informando que o carrinho está vazio
            cartItemsContainer.innerHTML = '<p>Seu carrinho está vazio.</p>';
            return;  // Sai da função se o carrinho estiver vazio
        }

        // Itera sobre cada produto no carrinho
        cart.forEach(product => {
            // Cria um novo elemento div para representar um item do carrinho
            const item = document.createElement('div');
            item.className = 'cart-item';  // Define a classe do item
            // Define o conteúdo HTML do item com a imagem, nome, preço e botão de remoção
            item.innerHTML = `
                <img src="${product.image}" alt="${product.name}">
                <div class="info">
                    <h3>${product.name}</h3>
                    <p class="price">${product.price}</p>
                    <button class="remove-from-cart" data-id="${product.id}">Remover</button>
                </div>
            `;
            // Adiciona o item ao contêiner de itens do carrinho
            cartItemsContainer.appendChild(item);
        });
    }

    // Função para remover um item do carrinho
    function removeFromCart(productId) {
        // Filtra o carrinho para remover o produto com o ID correspondente
        cart = cart.filter(product => product.id != productId);
        // Atualiza o localStorage com o carrinho modificado
        localStorage.setItem('cart', JSON.stringify(cart));
        // Atualiza a exibição dos itens do carrinho
        displayCartItems();
    }

    // Adiciona um evento de clique ao contêiner de itens do carrinho
    cartItemsContainer.addEventListener('click', function (event) {
        // Verifica se o alvo do clique é um botão de remoção
        if (event.target.classList.contains('remove-from-cart')) {
            // Obtém o ID do produto do atributo data-id do botão
            const productId = event.target.getAttribute('data-id');
            // Chama a função para remover o produto do carrinho
            removeFromCart(productId);
        }
    });

    // Adiciona um evento de clique ao botão para limpar o carrinho
    clearCartButton.addEventListener('click', function () {
        // Limpa o carrinho definindo-o como um array vazio
        cart = [];
        // Atualiza o localStorage com o carrinho vazio
        localStorage.setItem('cart', JSON.stringify(cart));
        // Atualiza a exibição dos itens do carrinho
        displayCartItems();
    });

    // Chama a função para exibir os itens do carrinho ao carregar a página
    displayCartItems();
});
