//Grafico
google.charts.load('current', {'packages': ['corechart']});
google.charts.setOnLoadCallback(drawChart);
//arrays dos graficos
function drawChart(){
    const data= google.visualization.arrayToDataTable([
        ['Idade', 'Mhl'],
        ['18-21',690],
        ['22-25',970],
        ['26-29',1780],
        ['30-33',700],
        ['34-37',500],
        ['38+',466],
    ]);
    //titulo grafico
    const options= {
        title: 'Idade dos clientes'
    };
    //desenha o grafico pegando o id "myChart"
    const chart = new google.visualization.PieChart(document.getElementById('mychart'));
    chart.draw(data, options);
}